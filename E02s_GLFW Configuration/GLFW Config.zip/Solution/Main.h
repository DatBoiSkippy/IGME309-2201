/*--------------------------------------------------------------------------------------------------
This project was generated in 2013
--------------------------------------------------------------------------------------------------*/
#ifndef _MAIN_H
#define _MAIN_H

// Include standard headers
#include <Windows.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>


#include "GL\glew.h"
#include "GLFW\glfw3.h"

#include "GLM\glm.hpp"

#include "OpenGL-Tutorials\shader.hpp"


#endif //_MAIN_H
